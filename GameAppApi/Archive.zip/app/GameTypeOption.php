<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GameTypeOption extends Model
{
    protected $fillable = ['name', 'game"status'];
}
