<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<div>
    <h1 style="color: #0000ff">Parcel-it</h1><hr><br>

    <div><h3>Parcel-it: Delivery Status</h3></div>
    <br>
    <div>Dear {{$username}},</div><br>
    <div>{{$msg}}</div><br>

</div>
</body>
</html>